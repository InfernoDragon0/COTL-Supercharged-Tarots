# Changelog

### v1.0.2
- Fixed both cards collected when choosing a tarot
- Added a config to fix if the card is not collected when chosen
- Added Multishot Card
- Added Blunder Buster Card
- Added The Gunslinger Card
- Added Resilient Gunner Card

### v1.0.1
- Added Config files
- Added Relic Overdrive Card

### v1.0.0
- Initial Release